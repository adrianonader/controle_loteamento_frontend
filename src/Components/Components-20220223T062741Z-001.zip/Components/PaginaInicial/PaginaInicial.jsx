import React from "react";

function PaginaInicial() {
  return <h1>Pagina Inicial</h1>;
}

export default PaginaInicial;
